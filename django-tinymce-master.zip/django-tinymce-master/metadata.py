name = 'tinymce'
authors = 'Joost Cassee, Aljosa Mohorovic'
version = '1.5.1b4'
release = version
